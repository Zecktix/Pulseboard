'use strict';
// Builds pulseboard.js: the server with the dashboard page compressed inside it, so users need one file.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const server = fs.readFileSync(path.join(__dirname, 'src', 'server.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, 'src', 'index.html'));
const line = "const PAGE_B64 = '__PAGE__';";
if (!server.includes(line)) throw new Error('Placeholder not found in src/server.js');
const b64 = zlib.gzipSync(html, { level: 9 }).toString('base64');
const out = server.replace(line, () => `const PAGE_B64 = '${b64}';`);
fs.writeFileSync(path.join(__dirname, 'pulseboard.js'), out);
fs.mkdirSync(path.join(__dirname, 'docs'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'docs', 'index.html'), html); // GitHub Pages serves /docs
console.log(`Built pulseboard.js (${Math.round(out.length / 1024)} KB) from src/server.js and src/index.html`);
