'use strict';
// Zero-dependency API tests. Starts a fake Shopify and the real server, then checks the behavior.
const http = require('http');
const assert = require('assert');

const fake = http.createServer((req, res) => {
  let b = ''; req.on('data', c => b += c); req.on('end', () => {
    const { query, variables } = JSON.parse(b || '{}');
    if (req.url.startsWith('/admin/oauth/')) { const ok = JSON.parse(b).code === 'goodcode'; res.writeHead(ok ? 200 : 400, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(ok ? { access_token: 'good-token-123', scope: 'read_reports' } : { error: 'bad' })); }
    if (req.headers['x-shopify-access-token'] !== 'good-token-123') { res.writeHead(401); return res.end('{}'); }
    res.setHeader('Content-Type', 'application/json');
    if (/marketingActivities/.test(query)) return res.end(JSON.stringify({ data: { marketingActivities: { nodes: [{ id: '1', createdAt: '2026-10-01T00:00:00Z', adSpend: { amount: '25.0' } }] } } }));
    res.end(JSON.stringify({ data: { shopifyqlQuery: { parseErrors: [], tableData: { columns: [{ name: 'day', dataType: 'DAY_TIMESTAMP' }, { name: 'orders', dataType: 'INTEGER' }], rows: [{ day: '2026-10-27', orders: '3' }, { day: '2026-10-28', orders: '0' }] } }, shop: { currencyCode: 'USD', myshopifyDomain: 'demo.myshopify.com' } } }));
  });
});

async function main() {
  await new Promise(r => fake.listen(0, '127.0.0.1', r));
  Object.assign(process.env, { PORT: '3100', PULSEBOARD_STORE_FILE: require('path').join(require('os').tmpdir(), 'pulseboard-test-store.json'), NO_OPEN: '1', SHOPIFY_STORE: 'demo.myshopify.com', SHOPIFY_ACCESS_TOKEN: 'good-token-123', SHOPIFY_API_BASE: `http://127.0.0.1:${fake.address().port}` });
  require('fs').rmSync(process.env.PULSEBOARD_STORE_FILE, { force: true }); // start clean, not from a previous run
  const { server } = require('../pulseboard.js');
  await new Promise(r => server.listen(3100, '127.0.0.1', r));
  const url = p => `http://localhost:3100${p}`;
  const post = (p, body, headers = {}) => fetch(url(p), { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
  let n = 0; const ok = (name) => console.log(`ok ${++n} - ${name}`);

  const home = await fetch(url('/')); assert.strictEqual(home.status, 200);
  assert.ok((await home.text()).includes('<title>Pulseboard</title>')); ok('serves the dashboard HTML');
  assert.strictEqual((await fetch(url('/server.js'))).status, 404); ok('does not serve source files');
  const s0 = await (await fetch(url('/api/status'))).json(); assert.strictEqual(s0.configured, true); assert.strictEqual(s0.shop, 'demo.myshopify.com'); assert.strictEqual(s0.app, false); ok('reports status');
  const q = await (await post('/api/shopifyql', { query: 'FROM sales SHOW day, orders TIMESERIES day SINCE -1d UNTIL today' })).json();
  assert.deepStrictEqual(q.rows, [['2026-10-27', '3'], ['2026-10-28', '0']]);
  assert.strictEqual(q.currencyCode, 'USD'); ok('normalizes ShopifyQL rows to arrays');
  assert.strictEqual((await post('/api/shopifyql', { query: 'mutation { x }' })).status, 400); ok('rejects non-ShopifyQL queries');
  assert.strictEqual((await post('/api/shopifyql', { query: 'FROM sales SHOW orders; DROP' })).status, 400); ok('rejects unsafe characters');
  const m = await (await post('/api/marketing', {})).json();
  assert.strictEqual(m.data.marketingActivities.nodes[0].adSpend.amount, '25.0'); ok('returns marketing activities');
  assert.strictEqual((await post('/api/shopifyql', { query: 'FROM sales SHOW orders SINCE -1d UNTIL today' }, { Origin: 'http://evil.example' })).status, 403); ok('blocks cross-origin requests');
  // connect and disconnect flow (what the in-app form uses)
  assert.strictEqual((await post('/api/disconnect', {})).status, 200);
  assert.strictEqual((await (await fetch(url('/api/status'))).json()).configured, false); ok('disconnect clears the connection');
  assert.strictEqual((await post('/api/shopifyql', { query: 'FROM sales SHOW orders SINCE -1d UNTIL today' })).status, 503); ok('refuses queries until connected');
  assert.strictEqual((await post('/api/connect', { store: 'not a store!', token: 'good-token-123' })).status, 400); ok('rejects an invalid store name');
  assert.strictEqual((await post('/api/connect', { store: 'demo', token: 'bad-token-123' })).status, 401); ok('rejects a bad token and stays disconnected');
  assert.strictEqual((await (await fetch(url('/api/status'))).json()).configured, false);
  const c = await (await post('/api/connect', { store: 'https://admin.shopify.com/store/demo', token: 'good-token-123' })).json();
  assert.deepStrictEqual(c, { configured: true, shop: 'demo.myshopify.com' }); ok('connects with a pasted store address and token');
  assert.strictEqual((await post('/api/marketing', {})).status, 200); ok('works after connecting');
  assert.strictEqual(require('../pulseboard.js').normalizeStore('My-Store'), 'my-store.myshopify.com'); ok('normalizes store names');
  await post('/api/disconnect', {});
  // OAuth login: store name, Shopify permission screen, verified callback
  const crypto = require('crypto'), startOf = shop => fetch(url('/auth/shopify/start?shop=' + shop), { redirect: 'manual' });
  assert.strictEqual((await startOf('demo')).status, 400); ok('refuses to start the login before the one-time app setup');
  assert.strictEqual((await post('/api/shopify/app', { id: 'x', secret: 'y' })).status, 400); ok('rejects malformed app credentials');
  assert.strictEqual((await post('/api/shopify/app', { id: 'client_id_12345', secret: 'client_secret_12345' })).status, 200);
  assert.strictEqual((await startOf('not a store!')).status, 400); ok('rejects an invalid store name');
  const go = await startOf('demo'), at = new URL(go.headers.get('location'));
  assert.strictEqual(go.status, 302); assert.strictEqual(at.host, 'demo.myshopify.com'); assert.strictEqual(at.pathname, '/admin/oauth/authorize');
  assert.strictEqual(at.searchParams.get('client_id'), 'client_id_12345'); assert.ok(at.searchParams.get('scope').includes('read_reports'));
  assert.ok(at.searchParams.get('redirect_uri').endsWith('/auth/shopify/callback')); ok('login redirects to Shopify\'s permission screen');
  const sign = p => { const q = new URLSearchParams(p), msg = [...q.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('&'); q.set('hmac', crypto.createHmac('sha256', 'client_secret_12345').update(msg).digest('hex')); return q.toString(); };
  const state = at.searchParams.get('state'), base = { code: 'goodcode', shop: 'demo.myshopify.com', state, timestamp: '1700000000' };
  const forged = new URLSearchParams({ ...base, hmac: 'f'.repeat(64) }).toString();
  assert.strictEqual((await fetch(url('/auth/shopify/callback?' + forged), { redirect: 'manual' })).status, 400); ok('rejects a callback with a bad signature');
  const go2 = await startOf('demo'), state2 = new URL(go2.headers.get('location')).searchParams.get('state');
  assert.strictEqual((await fetch(url('/auth/shopify/callback?' + sign({ ...base, state: 'unknown' })), { redirect: 'manual' })).status, 400); ok('rejects an unknown state');
  const cb = await fetch(url('/auth/shopify/callback?' + sign({ ...base, state: state2 })), { redirect: 'manual' });
  assert.strictEqual(cb.status, 302); assert.strictEqual(cb.headers.get('location'), '/?shopify=connected'); ok('completes the login and saves the connection');
  const stt = await (await fetch(url('/api/status'))).json();
  assert.strictEqual(stt.configured, true); assert.strictEqual(stt.shop, 'demo.myshopify.com'); assert.strictEqual(stt.app, true); ok('reports connected after the permission screen');
  await post('/api/disconnect', {});
  assert.strictEqual((await (await fetch(url('/api/status'))).json()).app, true); ok('disconnect keeps the one-time app setup');
  server.close(); fake.close(); console.log(`\n${n} passed`);
}
main().catch(e => { console.error(e); process.exit(1); });
