#!/usr/bin/env node
'use strict';
// Pulseboard local server. Zero dependencies, Node 18+.
// Serves the dashboard and proxies a small, read-only set of Shopify queries so the
// access token stays on this computer and never reaches the browser.
const http = require('http');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');
const path = require('path');
const { exec } = require('child_process');

if (typeof fetch !== 'function') { console.error('Node 18 or newer is required. Get it at https://nodejs.org'); process.exit(1); }

(function loadEnv() { // optional: .env is still supported, but the in-app connect form is the easy way
  try {
    for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
      if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch (_) { /* no .env file */ }
})();

let PORT = Number(process.env.PORT) || 3000; // moves up by one if the port is busy
const HOST = process.env.HOST || '127.0.0.1';
const VERSION = process.env.SHOPIFY_API_VERSION || '2026-07';
const STORE_FILE = process.env.PULSEBOARD_STORE_FILE || path.join(__dirname, '.pulseboard-store.json');
// The dashboard page. build.js replaces the next line with the compressed page so that
// pulseboard.js is one self-contained file. Run unbuilt, it reads src/index.html instead.
const PAGE_B64 = '__PAGE__';
let pageCache;
const page = () => pageCache || (pageCache = PAGE_B64.startsWith('__')
  ? fs.readFileSync(path.join(__dirname, 'index.html'))
  : zlib.gunzipSync(Buffer.from(PAGE_B64, 'base64')));

const fail = (message, status) => Object.assign(new Error(message), { status });

// ---- connection settings: environment first, otherwise the file the connect form saves ----
const cfg = { store: '', token: '', refresh: '', expires: 0 };
const app = { id: '', secret: '' }; // the Shopify app used for the permission screen (set up once)
const SCOPES = 'read_reports,read_orders,read_customers,read_marketing_events';
function normalizeStore(input) {
  let s = String(input || '').trim().toLowerCase();
  const admin = s.match(/admin\.shopify\.com\/store\/([a-z0-9-]+)/);
  if (admin) return `${admin[1]}.myshopify.com`;
  s = s.replace(/^https?:\/\//, '').replace(/[/?#].*$/, '');
  if (/^[a-z0-9][a-z0-9-]*$/.test(s)) s += '.myshopify.com';
  return /^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(s) ? s : null;
}
function saveState() {
  const has = cfg.token || app.id;
  try {
    if (!has) fs.unlinkSync(STORE_FILE);
    else fs.writeFileSync(STORE_FILE, JSON.stringify({ store: cfg.store, token: cfg.token, refresh: cfg.refresh, expires: cfg.expires, app }), { mode: 0o600 });
  } catch (_) { /* still works for this session */ }
}
(function loadSaved() {
  let j = {};
  try { j = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')); } catch (_) { /* nothing saved yet */ }
  const envStore = normalizeStore(process.env.SHOPIFY_STORE), envToken = process.env.SHOPIFY_ACCESS_TOKEN || '';
  if (envStore && envToken) { cfg.store = envStore; cfg.token = envToken; }
  else if (normalizeStore(j.store) && j.token) { cfg.store = j.store; cfg.token = j.token; cfg.refresh = j.refresh || ''; cfg.expires = j.expires || 0; }
  if (j.app && typeof j.app === 'object') { app.id = j.app.id || ''; app.secret = j.app.secret || ''; }
  if (process.env.SHOPIFY_CLIENT_ID && process.env.SHOPIFY_CLIENT_SECRET) { app.id = process.env.SHOPIFY_CLIENT_ID; app.secret = process.env.SHOPIFY_CLIENT_SECRET; }
})();
const configured = () => Boolean(cfg.store && cfg.token);
const apiBase = () => process.env.SHOPIFY_API_BASE || `https://${cfg.store}`;

async function gql(query, variables) {
  if (cfg.refresh && cfg.expires && Date.now() > cfg.expires) await refreshShopify();
  const res = await fetch(`${apiBase()}/admin/api/${VERSION}/graphql.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Shopify-Access-Token': cfg.token },
    body: JSON.stringify({ query, variables }),
  });
  if (res.status === 401 || res.status === 403) throw fail('Shopify rejected the access token.', 401);
  if (!res.ok) throw fail(`Shopify returned HTTP ${res.status}.`, 502);
  const json = await res.json();
  if (json.errors && !json.data) {
    const msg = json.errors.map(e => e.message).join('; ');
    throw fail(msg, /access denied|scope/i.test(msg) ? 401 : 502);
  }
  return json;
}

const SHOPIFYQL = 'query($q:String!){shopifyqlQuery(query:$q){tableData{columns{name dataType displayName}rows}parseErrors}shop{currencyCode myshopifyDomain}}';
const ALLOWED_QUERY = /^FROM\s+(sales|sessions|payments|customers)\s/i;

// Returns the same shape the Claude connector returns: columns plus rows as arrays of strings.
async function shopifyql(q) {
  if (typeof q !== 'string' || q.length > 600 || /[;{}]/.test(q) || !ALLOWED_QUERY.test(q)) {
    throw fail('Only read-only ShopifyQL queries on sales, sessions, payments or customers are allowed.', 400);
  }
  const json = await gql(SHOPIFYQL, { q });
  const r = json.data && json.data.shopifyqlQuery;
  if (!r) throw fail('Shopify returned no ShopifyQL result. The app needs the read_reports scope.', 401);
  if (r.parseErrors && r.parseErrors.length) throw fail(r.parseErrors.join('; '), 400);
  const t = r.tableData || { columns: [], rows: [] };
  const columns = t.columns.map(c => ({ name: c.name, dataType: c.dataType }));
  const rows = (t.rows || []).map(o => Array.isArray(o) ? o.map(String) : columns.map(c => (o[c.name] == null ? '' : String(o[c.name]))));
  return { query: q, columns, rows, rowCount: rows.length, currencyCode: json.data.shop.currencyCode, shopDomain: json.data.shop.myshopifyDomain };
}

const MARKETING = '{ marketingActivities(first: 50, sortKey: CREATED_AT, reverse: true) { nodes { id createdAt adSpend { amount } } } }';
async function marketing() {
  try { return { data: (await gql(MARKETING)).data }; }
  catch (e) { if (e.status === 401) return { data: null }; throw e; } // scope missing: treat as unavailable
}

// Checks the store and token with a real query, then remembers them on this computer only.
async function connect(body) {
  const store = normalizeStore(body.store);
  const token = String(body.token || '').trim();
  if (!store) throw fail('That does not look like a Shopify store. Use the name or address, for example my-store or my-store.myshopify.com.', 400);
  if (token.length < 10 || token.length > 300 || /\s/.test(token)) throw fail('The access token looks incomplete. Copy the whole token, it usually starts with shpat_.', 400);
  const previous = { ...cfg };
  Object.assign(cfg, { store, token, refresh: '', expires: 0 });
  try { await shopifyql('FROM sales SHOW orders SINCE -1d UNTIL today'); }
  catch (e) {
    Object.assign(cfg, previous);
    if (e.status === 401) throw fail('Shopify rejected that token, or the app is missing the read_reports permission. Check the token and the app scopes, then try again.', 401);
    throw e;
  }
  saveState();
  return { configured: true, shop: store };
}
function disconnect() {
  Object.assign(cfg, { store: '', token: '', refresh: '', expires: 0 });
  saveState();
}

// ---- Shopify sign-in: OAuth authorization code grant. The user types a store name and clicks Allow on Shopify's own page. ----
const redirectUri = () => `http://localhost:${PORT}/auth/shopify/callback`;
const pending = new Map(); // state -> shop, kept in memory for 10 minutes
const b64u = b => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const appReady = () => Boolean(app.id && app.secret);

function shopifyStart(shopInput) {
  const shop = normalizeStore(shopInput);
  if (!shop) throw fail('That does not look like a Shopify store. Use the name or address, for example my-store.', 400);
  if (!appReady()) throw fail('The one-time Shopify app setup is not finished yet.', 400);
  const state = b64u(crypto.randomBytes(16));
  pending.set(state, shop);
  setTimeout(() => pending.delete(state), 600000).unref();
  return `https://${shop}/admin/oauth/authorize?` + new URLSearchParams({ client_id: app.id, scope: SCOPES, redirect_uri: redirectUri(), state });
}
function validHmac(q) { // Shopify signs the callback query with the app secret
  const given = q.get('hmac');
  if (!given || !app.secret) return false;
  const msg = [...q.entries()].filter(([k]) => k !== 'hmac').sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([k, v]) => `${k}=${v}`).join('&');
  const mine = Buffer.from(crypto.createHmac('sha256', app.secret).update(msg).digest('hex')), theirs = Buffer.from(given);
  return mine.length === theirs.length && crypto.timingSafeEqual(mine, theirs);
}
async function shopifyToken(shop, body) {
  const res = await fetch((process.env.SHOPIFY_API_BASE || `https://${shop}`) + '/admin/oauth/access_token', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ client_id: app.id, client_secret: app.secret, ...body }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || !j.access_token) throw fail('Shopify did not accept the sign-in' + (j.error_description ? ': ' + j.error_description : '.'), 401);
  return j;
}
function takeToken(j) {
  cfg.token = j.access_token; cfg.refresh = j.refresh_token || cfg.refresh;
  cfg.expires = j.expires_in ? Date.now() + j.expires_in * 1000 - 60000 : 0;
}
async function refreshShopify() { takeToken(await shopifyToken(cfg.store, { grant_type: 'refresh_token', refresh_token: cfg.refresh })); saveState(); }
async function shopifyCallback(q) {
  const shop = pending.get(q.get('state'));
  if (!shop) throw fail('This Shopify sign-in link expired. Start again from the dashboard.', 400);
  pending.delete(q.get('state'));
  if (q.get('shop') !== shop || !validHmac(q)) throw fail('The response from Shopify could not be verified, so it was ignored.', 400);
  const previous = { ...cfg };
  takeToken(await shopifyToken(shop, { code: q.get('code') }));
  cfg.store = shop;
  try { await shopifyql('FROM sales SHOW orders SINCE -1d UNTIL today'); }
  catch (e) {
    Object.assign(cfg, previous);
    if (e.status === 401) throw fail('Signed in, but the app is missing the read_reports permission. Add it to the app, release a new version, and sign in again.', 401);
    throw e;
  }
  saveState();
}

function hostAllowed(req) {
  const ok = new Set([`localhost:${PORT}`, `127.0.0.1:${PORT}`, `[::1]:${PORT}`, ...(process.env.ALLOWED_HOSTS || '').split(',').filter(Boolean)]);
  if (!ok.has(req.headers.host)) return false;
  const origin = req.headers.origin;
  return !origin || origin === `http://${req.headers.host}`;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', c => { s += c; if (s.length > 10000) { reject(fail('Request too large.', 413)); req.destroy(); } });
    req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch (_) { reject(fail('Invalid JSON.', 400)); } });
  });
}

const send = (res, status, body, type = 'application/json') => {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      return send(res, 200, page(), 'text/html; charset=utf-8');
    }
    if (req.method === 'GET' && url.pathname.startsWith('/auth/shopify/')) {
      if (!hostAllowed(req)) return send(res, 403, { error: 'Forbidden host or origin.' });
      try {
        if (url.pathname === '/auth/shopify/start') { res.writeHead(302, { Location: shopifyStart(url.searchParams.get('shop')) }); return res.end(); }
        if (url.pathname === '/auth/shopify/callback') {
          if (url.searchParams.get('error')) throw fail('Shopify sign-in was cancelled or refused.', 400);
          await shopifyCallback(url.searchParams);
          res.writeHead(302, { Location: '/?shopify=connected' }); return res.end();
        }
      } catch (e) {
        console.error('[pulseboard]', e.message);
        return send(res, e.status || 500, `<!doctype html><meta charset=utf-8><title>Shopify</title><body style="font:16px system-ui;max-width:520px;margin:15vh auto;padding:0 20px"><h2>Shopify could not be connected</h2><p>${String(e.message).replace(/[<>&]/g, '')}</p><p><a href="/">Back to the dashboard</a></p>`, 'text/html; charset=utf-8');
      }
    }
    if (!url.pathname.startsWith('/api/')) return send(res, 404, { error: 'Not found' });
    if (!hostAllowed(req)) return send(res, 403, { error: 'Forbidden host or origin.' });
    if (req.method === 'GET' && url.pathname === '/api/status') return send(res, 200, { configured: configured(), shop: configured() ? cfg.store : null, app: appReady(), redirect: redirectUri() });
    if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' });
    const body = await readBody(req);
    if (url.pathname === '/api/shopify/app') {
      const id = String(body.id || '').trim(), secret = String(body.secret || '').trim();
      if (!/^[A-Za-z0-9_-]{8,128}$/.test(id) || !/^[A-Za-z0-9_-]{8,128}$/.test(secret)) return send(res, 400, { error: 'Those do not look like a Client ID and Secret. Copy both from your app page on dev.shopify.com.' });
      app.id = id; app.secret = secret; saveState();
      return send(res, 200, { app: true, redirect: redirectUri() });
    }
    if (url.pathname === '/api/connect') return send(res, 200, await connect(body));
    if (url.pathname === '/api/disconnect') { disconnect(); return send(res, 200, { configured: false }); }
    if (!configured()) return send(res, 503, { error: 'Shopify is not connected yet.' });
    if (url.pathname === '/api/shopifyql') return send(res, 200, await shopifyql(body.query));
    if (url.pathname === '/api/marketing') return send(res, 200, await marketing());
    return send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error('[pulseboard]', e.message);
    send(res, e.status || 500, { error: e.message });
  }
});

function openBrowser(url) {
  if (process.env.NO_OPEN) return;
  const cmd = process.platform === 'win32' ? `start "" "${url}"` : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => { /* ignore: the URL is printed anyway */ });
}

function start(port, retries) {
  PORT = port;
  server.once('error', e => {
    if (e.code === 'EADDRINUSE' && retries > 0) return start(port + 1, retries - 1);
    console.error(e.code === 'EADDRINUSE' ? 'No free port found between 3000 and 3010. Close other programs and try again.' : e.message);
    process.exit(1);
  });
  server.listen(port, HOST);
}
if (require.main === module) server.on('listening', () => { // fires once, with the port that actually worked
  server.removeAllListeners('error');
  const url = `http://localhost:${server.address().port}`;
  console.log(`Pulseboard is running at ${url}  (press Ctrl+C to stop)`);
  console.log(configured() ? `Shopify: connected to ${cfg.store} (read-only)` : 'Shopify: not connected yet. Click "Log in to Shopify" in the dashboard.');
  openBrowser(url);
});
if (require.main === module) start(PORT, 10);
module.exports = { server, normalizeStore };
